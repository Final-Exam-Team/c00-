﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace 学生管理系统
{
    internal class DataBase
    {
        public MySqlConnection Connection()
        {
            string str = "server = localhost; user = root; database = student; password =20020113wyxtz";
            //string str = "Data Sourse = LAPTOP-K6KOLB5K;Initial Catalog=student;Integrated Security=True";
            MySqlConnection sc = new MySqlConnection(str);
            sc.Open();                     //打开数据库链接
            return sc;
        }
        public MySqlCommand Command(string sql)
        {
            MySqlCommand cmd = new MySqlCommand(sql, Connection());
            return cmd;
        }

        //用于数据库的增加、删除以及更新
        public int Excute(string sql)
        {
            return Command(sql).ExecuteNonQuery();
        }

        //用于选择数据
        public MySqlDataReader read(string sql)
        {
            return Command(sql).ExecuteReader();
        }
    }
}
