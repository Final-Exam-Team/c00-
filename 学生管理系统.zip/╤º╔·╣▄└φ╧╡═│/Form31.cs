﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 学生管理系统
{
    public partial class Form31 : Form
    {
        string SID;
        public Form31(string StudentID)
        {
            SID = StudentID;
            InitializeComponent();
            Table();
        }
        public void Table()
        {
            dataGridView1.Rows.Clear();
            string sql = "select*from courserecord where sId='"+SID+"'";
            DataBase db = new DataBase();
            IDataReader dr = db.read(sql);
            while (dr.Read())
            {
                string CID=dr["cId"].ToString();
                string sql2 = "select*from course1 where Id='" + CID + "'";
                IDataReader dr2 = db.read(sql2);
                dr2.Read();
                string a, b, c, d;
                a = dr2["Id"].ToString();
                b = dr2["Name"].ToString();
                c = dr2["Teacher"].ToString();
                d = dr2["Credit"].ToString();
                string[] str = { a, b, c, d };
                dataGridView1.Rows.Add(str);
                dr2.Close();
            }
            dr.Close();//关闭连接
        }

        private void 取消这门课ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string CID=dataGridView1.SelectedCells[0].Value.ToString();
            string sql = "delete from courserecord where sId='" + SID + "'and cId='" + CID + "'";
            DataBase db = new DataBase();
            db.Excute(sql);
            Table();
        }
    }
}
