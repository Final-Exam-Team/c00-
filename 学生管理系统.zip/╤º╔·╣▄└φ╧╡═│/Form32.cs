﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 学生管理系统
{
    public partial class Form32 : Form
    {
        string SID;
        public Form32()
        {
            InitializeComponent();
        }
        public Form32(string sid)
        {
            InitializeComponent();
            SID = sid;
            string sql = "select*from student1 where Id='" + SID + "'";
            DataBase db = new DataBase();   
            db.read(sql);
            IDataReader dr=db.read(sql);
            dr.Read();
            textBox1.Text=dr["Password"].ToString();
            dr.Close();
        }

        private void Form32_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "Update student1 set Password='" + textBox2.Text + "'where Id='" + SID + "'";
            DataBase db = new DataBase();
            db.Excute(sql);
            int i = db.Excute(sql);
            if (i > 0)
            {
                MessageBox.Show("密码修改成功");
                textBox1.Text = null;
                textBox2.Text = null;
            }
        }
    }
}
