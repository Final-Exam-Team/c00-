﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 学生管理系统
{
    public partial class Form3 : Form
    {
        string SID;//记录登录选课系统账户的学号
        public Form3(string StudentID)
        {
            SID = StudentID;
            InitializeComponent();
            Time1.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            toolStripStatusLabel1.Text = "欢迎" + SID + "登录学生选课系统";
            timer1.Start();
            Table();
        }

        public void Table()
        {
            dataGridView1.Rows.Clear();
            string sql = "select*from course1";
            DataBase db = new DataBase();
            IDataReader dr = db.read(sql);
            while (dr.Read())
            {
                string a, b, c, d;
                a = dr["Id"].ToString();
                b = dr["Name"].ToString();
                c = dr["Teacher"].ToString();
                d = dr["Credit"].ToString();
                string[] str = { a, b, c, d };
                dataGridView1.Rows.Add(str);
            }
            dr.Close();//关闭连接
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Time1.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();//结束整个程序
        }

        private void 选课ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string CID = dataGridView1.SelectedCells[0].Value.ToString();
            string sql1 = "select*from courserecord where sId='" + SID + "'and cId='" + CID + "'";
            DataBase db = new DataBase();
            IDataReader dc = db.read(sql1);
            if (!dc.Read())
            {
                string sql = "Insert into courserecord values('" + SID + "','" + CID + "')";
                int i = db.Excute(sql);
                if (i > 0)
                {
                    MessageBox.Show("选课成功");
                }

            }
            else
            {
                MessageBox.Show("不允许重复选课");
            }
            
        }

        private void 我的课程ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form31 f=new Form31(SID);
            dataGridView1.Rows.Clear();
            f.Show();
            
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void 修改个人密码ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form32 f = new Form32(SID);
            f.ShowDialog();
        }
    }
}
